class SortNode < BlockFixNode

  def to_s
    "Sort"
  end

  def cls
    self
  end
end
