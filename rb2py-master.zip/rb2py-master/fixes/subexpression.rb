# Marker for nodes representing subexpressions

class SubexpressionNode < Node
  # pass
end