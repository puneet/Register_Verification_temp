class BlockGivenTestNode < Node

  def initialize(ruby_node)
    super(ruby_node)
  end

  def to_s
    "BlockGivenTest"
  end
end
