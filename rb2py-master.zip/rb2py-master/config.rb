$rescue_exceptions = true
$require_implemented_gen = true
$require_implemented_get_result = true
