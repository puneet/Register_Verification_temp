class NextNode
  def real_gen
    $pygen.write 'continue'
  end
end