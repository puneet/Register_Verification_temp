class WhileNode
  def real_gen
    $pygen.while condition, statements
  end
end