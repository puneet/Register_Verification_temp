class NilNode
  def real_gen
    $pygen.write 'None'
  end
end