class UntilNode
  def real_gen
    $pygen.until condition, statements
  end
end