class PrivateNode
  def real_gen
    # pass
  end
end