class UserExceptionAncestor

  def self.fullname
    'Exception'
  end
end
