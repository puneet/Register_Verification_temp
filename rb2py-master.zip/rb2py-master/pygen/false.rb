class FalseNode
  def real_gen
    $pygen.write 'False'
  end
end
