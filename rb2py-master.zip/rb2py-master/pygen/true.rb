class TrueNode
  def real_gen
    $pygen.write 'True'
  end
end
