class BreakNode
  def real_gen
    $pygen.write 'break'
  end
end