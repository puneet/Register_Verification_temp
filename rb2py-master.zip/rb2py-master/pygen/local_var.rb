class LocalVariableNode

  def real_gen
    $pygen.write name
  end
end
