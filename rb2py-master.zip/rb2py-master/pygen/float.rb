# Floating number

class FloatNode
  def real_gen
    child.gen
  end
end
