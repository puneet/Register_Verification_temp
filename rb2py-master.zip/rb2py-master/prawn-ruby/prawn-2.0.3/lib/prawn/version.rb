# encoding: utf-8

module Prawn
  VERSION = "2.0.3"
end
