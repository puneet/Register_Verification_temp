class MathNode
  def pyfix_math
    $pygen.imports << 'math'
    self
  end
end